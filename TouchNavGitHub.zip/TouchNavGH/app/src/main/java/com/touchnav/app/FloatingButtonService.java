package com.touchnav.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;

public class FloatingButtonService extends Service {

    private static final String CHANNEL_ID = "touchnav_channel";
    private static final int NOTIF_ID = 1001;

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private GestureDetector gestureDetector;
    private Vibrator vibrator;

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private boolean isDragging = false;
    private static final int DRAG_THRESHOLD = 10;

    private long lastTapTime = 0;
    private static final long DOUBLE_TAP_WINDOW = 350;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_button, null);

        int sizePx = dpToPx(40 + (int)(AppPrefs.getSize(this) * 0.5f));

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                sizePx, sizePx, layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.x = AppPrefs.getPosX(this);
        params.y = AppPrefs.getPosY(this);

        floatingView.setAlpha(AppPrefs.getOpacity(this) / 100f);

        setupGestureDetector();
        setupTouchListener();
        windowManager.addView(floatingView, params);
        AppPrefs.setServiceRunning(this, true);
    }

    private void setupGestureDetector() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getRawX() - e1.getRawX();
                float dy = e2.getRawY() - e1.getRawY();
                boolean horizontal = Math.abs(dx) > Math.abs(dy);
                if (horizontal && Math.abs(dx) > 40 && Math.abs(velocityX) > 100) {
                    executeAction(AppPrefs.getGesture(FloatingButtonService.this,
                            dx > 0 ? AppPrefs.KEY_SWIPE_RIGHT : AppPrefs.KEY_SWIPE_LEFT));
                    return true;
                } else if (!horizontal && Math.abs(dy) > 40 && Math.abs(velocityY) > 100) {
                    executeAction(AppPrefs.getGesture(FloatingButtonService.this,
                            dy > 0 ? AppPrefs.KEY_SWIPE_DOWN : AppPrefs.KEY_SWIPE_UP));
                    return true;
                }
                return false;
            }
        });
    }

    private void setupTouchListener() {
        floatingView.setOnTouchListener((v, event) -> {
            gestureDetector.onTouchEvent(event);
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isDragging = false;
                    initialX = params.x; initialY = params.y;
                    initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(event.getRawX() - initialTouchX) > DRAG_THRESHOLD ||
                        Math.abs(event.getRawY() - initialTouchY) > DRAG_THRESHOLD) {
                        isDragging = true;
                    }
                    if (isDragging && !AppPrefs.isLockPosition(this)) {
                        params.x = initialX + (int)(event.getRawX() - initialTouchX);
                        params.y = initialY + (int)(event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (isDragging) {
                        AppPrefs.setPos(this, params.x, params.y);
                    } else {
                        long now = System.currentTimeMillis();
                        if (now - lastTapTime < DOUBLE_TAP_WINDOW) {
                            lastTapTime = 0;
                            vibrate(30);
                            executeAction(AppPrefs.getGesture(this, AppPrefs.KEY_DOUBLE_TAP));
                        } else {
                            lastTapTime = now;
                            vibrate(15);
                            floatingView.postDelayed(() -> {
                                if (System.currentTimeMillis() - lastTapTime >= DOUBLE_TAP_WINDOW - 10) {
                                    executeAction(AppPrefs.getGesture(FloatingButtonService.this, AppPrefs.KEY_SINGLE_TAP));
                                }
                            }, DOUBLE_TAP_WINDOW);
                        }
                    }
                    return true;
            }
            return false;
        });
    }

    private void executeAction(String action) {
        vibrate(20);
        NavAccessibilityService.performAction(action);
    }

    private void vibrate(int ms) {
        if (!AppPrefs.isVibration(this) || vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(ms);
        }
    }

    private int dpToPx(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
        AppPrefs.setServiceRunning(this, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) stopSelf();
        return START_STICKY;
    }

    private Notification buildNotification() {
        PendingIntent openPending = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("TouchNav Aktif")
                .setContentText("Yüzen navigasyon düğmesi çalışıyor")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(openPending)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "TouchNav Servisi", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
